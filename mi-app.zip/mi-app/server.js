import express from "express";
import path from "path";

const app = express();
const __dirname = path.resolve();

// Servir archivos estáticos de 'public'
app.use(express.static(path.join(__dirname, "public")));

// Servir archivos raíz (resultado.txt, script.js, etc.)
app.get("/resultado.txt", (req, res) => {
  res.sendFile(path.join(__dirname, "resultado.txt"));
});

// Servir archivos raíz (resultado.txt, script.js, etc.)
app.get("/estado.txt", (req, res) => {
  res.sendFile(path.join(__dirname, "estado.txt"));
});


app.get("/script.js", (req, res) => {
  res.sendFile(path.join(__dirname, "script.js"));
});

app.listen(3000, () => {
  console.log("Servidor corriendo en http://localhost:3000");
});
