import { writeFile } from "fs/promises"; // Node.js moderno
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: "AIzaSyDtIjNXObkuYBzqKyenSNphy9JDPz83oA8" });

async function main(texto, archivo) {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: texto,
  });

  const resultado = response.text;

  // Guardar en archivo
  await writeFile(archivo, resultado, "utf-8");
  console.log("Archivo creado con éxito.");
}

// Ejemplo
main("Escribe un consejo acerca de como puedes mejorar tus finanzas que puedes aplicar en el día a día. Recomendarás un consejo cada dia. Algo breve y conciso, el texto irá en un párrafo corto. Solo el consejo, no quiero que des niguna introducción como: *El consejo para hoy*. Quiero que siempre me generes algo diferente, y si ya existe el archivo aún así pienses algo y lo sobreescribas", "resultado.txt");

const lista = ["milonario", "falta de trabajo", "malestar"]; 
main(`Analiza estas palabras: ${lista.join(', ')}. Califica del 1 al 10 el nivel de estabilidad económica que representan, siendo 10 el más alto. Responde únicamente con el número, sin texto adicional.`, "estado.txt");


