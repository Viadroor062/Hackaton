import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: "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",
});

const response = openai.responses.create({
  model: "gpt-5-nano",
  input: "write a haiku about ai",
  store: true,
});

response.then((result) => console.log(result.output_text));